require 'test_helper'

class BroadcastsHelperTest < ActionView::TestCase
end
