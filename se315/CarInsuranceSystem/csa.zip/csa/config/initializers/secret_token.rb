# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Csa::Application.config.secret_key_base = '79f40538c5484813fa3ff33e8c4b333aa7b8a5935d63a9b6cb30e3b35570096de47d6f50b4b7d6cc26c937241204f39aa04af2595fbab96de7e307151a1a78eb'
